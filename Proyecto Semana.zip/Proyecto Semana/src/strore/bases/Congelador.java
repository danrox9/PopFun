package strore.bases;

public class Congelador extends Refrigerador{
    
    public Congelador(){
    this("","",0.0,0,0);
    }
    
    public Congelador(String name, String desc, double price, int quantity, int temperatura){
    super(name,desc,price,quantity,temperatura);
    }
    
    
    
}
