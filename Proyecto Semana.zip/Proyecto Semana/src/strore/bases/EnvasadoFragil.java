
package strore.bases;

import strore.Item;

public class EnvasadoFragil extends Item{
    
    public EnvasadoFragil(String name, String desc, double price, int quantity) {
        super(name, desc, price, quantity);
    }
    
}
