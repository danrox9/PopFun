
package strore.bases;

import strore.Item;

public class EnvasadoNFragil extends Item{
    
    public EnvasadoNFragil(String name, String desc, double price, int quantity) {
        super(name, desc, price, quantity);
    }
    
}
