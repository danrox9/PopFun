
package strore.bases;

import strore.Item;

public class Refrigerador extends Item{
    private int temperatura;
    
    public Refrigerador(){
    this("","",0.0,0,0);
    }
    
    public Refrigerador(String name, String desc, double price, int quantity, int temperatura){
    super(name,desc,price,quantity);
    this.temperatura=temperatura;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    @Override
    public String toString() {
        return super.toString() + " Temperatura: " + temperatura;
    }
    
    
    
    
}
