
package strore.bases;

import strore.Item;

public class MostradorAlCorte extends Refrigerador{
    private double cantgramos;
    private String descMostrador;
    
    public MostradorAlCorte(){
    this("","",0.0,0,0,0.0,"");
    }
    
    public MostradorAlCorte(String name, String desc, double price, int quantity, int temperatura,double cantgramos, String descMostrador){
    super(name,desc,price,quantity,temperatura);
    this.cantgramos=cantgramos;
    this.descMostrador=descMostrador;
    }
    
}
