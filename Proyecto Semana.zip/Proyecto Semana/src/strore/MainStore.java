
package strore;

import strore.bases.Refrigerador;


public class MainStore {

 
    public static void main(String[] args) {
        Cart myCart = new Cart();
        System.out.println(myCart.toString());
        
        Item refri1 = new Refrigerador("Tomate","Fruta",13.33,5,11);
        myCart.add(refri1);
        System.out.println(myCart.toString());
//        Item item1 = new Item();
//        item1.setFields("Patatas", "Patata nueva", 1.45, 2);
//        myCart.add(item1);
//        System.out.println(myCart.toString());
//        
//        myCart.add("Naranjas", "Navel", 1.99, 3);
//        System.out.println(myCart.toString());
//        
////        myCart.clear();
////        myCart.display();
//
//        myCart.add("Fresas", "Huelva ricas", 5.99, 1);
//        System.out.println(myCart.toString());
//        
//        myCart.remove(1);
//        System.out.println(myCart.toString());
//        
//        myCart.remove(20);
//        System.out.println(myCart.toString());
//        
//        myCart.update(0, 4);
//        System.out.println(myCart.toString());
//        
//        myCart.update(10, 4);
//        System.out.println(myCart.toString());
//        
//        myCart.update(5, 4);
//        System.out.println(myCart.toString());
    }
    
}
