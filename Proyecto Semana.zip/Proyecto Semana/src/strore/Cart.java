
package strore;


public class Cart {
    private static final int MAX_ITEMS = 10;
    
    private int nextId = 0; //valores entre 0 y 9  
    
    private Item[] items=new Item[MAX_ITEMS];
    private double total = 0.0;

    public int getNextId() {
        return nextId;
    }

    public void setNextId(int nextId) {
        this.nextId = nextId;
    }

    public Item[] getItems() {
        return items;
    }

    public void setItems(Item[] items) {
        this.items = items;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    
    public void add(Item item){
        //check si esta lleno nextId 
        if (nextId >= MAX_ITEMS){
            System.out.println("Cart full");
            return;
        }
        items[nextId]=item;
        item.setId(nextId++);
        this.total+=item.getTotal();
    }
//    public void add(String name, String desc, double price, int quantity) {
//        Item newItem = new Item(name, desc, price, quantity);
//        add(newItem);
//    }
    
    public void update(int id, int newQty){
        if(indexInRange(id)==false){
            return;
        }
        if(items[id]==null){
            System.out.println("*-*-*-*- Index empty");
            return;
        }
        double oldTotal = items[id].getTotal();
        items[id].updateQuantity(newQty);
        this.total = this.total - oldTotal + items[id].getTotal();
        //opcion llamar a processItems
    }
    public void remove(int id){  //id de 0 a Max-1
        if(indexInRange(id)==false){
            return;
        }
        items[id] = null;
        processItems();
    }
    public boolean indexInRange(int id){
        if (id < 0 ){
            System.out.println("-*-*-*-* Index out");
            return false;
        }
        if(id >= MAX_ITEMS){
            System.out.println("-*-*-*-* Index out");
            return false;
        }
        return true;
    }
    public void processItems(){
        Item[] newItems=new Item[MAX_ITEMS];
        nextId=0;
        total=0.0;        
        for(Item item: items){
            if(item!=null){
                item.setId(nextId); //opcional
                newItems[nextId++] = item;
                total+=item.getTotal();
            }
        }
        items = newItems;
    }
    public void clear(){
        items=new Item[MAX_ITEMS];
        total=0.0;
        nextId=0;
    }
    
     @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-*-*-* Cart Details *-*-*\n");
        for (Item item : items) {
            if (item == null) {
                break;
            } else {
                sb.append(item.toString()).append("\n");
            }
        }
        sb.append("Total Cart: ").append(total).append("\n");
        return sb.toString();
    }

    
}
