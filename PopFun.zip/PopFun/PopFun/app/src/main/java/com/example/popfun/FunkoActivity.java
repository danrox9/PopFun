package com.example.popfun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FunkoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funko);
    }
}